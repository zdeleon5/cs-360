package com.example.cs_360_project_deleon;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.cs_360_project_deleon.databinding.ActivityMainBinding;
import com.example.cs_360_project_deleon.fragment.HomeFragment;
import com.example.cs_360_project_deleon.fragment.LoginFragment;
import com.example.cs_360_project_deleon.fragment.SMSFragment;
import com.example.cs_360_project_deleon.fragment.WeightFragment;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;

    private final HomeFragment homeFragment = new HomeFragment();
    private final WeightFragment weightFragment = new WeightFragment();
    private final SMSFragment smsFragment = new SMSFragment();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // load default fragment
        if (savedInstanceState == null) {
            switchFragment(new LoginFragment(), false);
        }

        binding.navView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_home) {
                switchFragment(homeFragment, true); // Or new HomeFragment()
                return true;
            } else if (itemId == R.id.navigation_grid) {
                switchFragment(weightFragment, true); // Or new GridFragment()
                return true;
            } else if (itemId == R.id.navigation_settings) {
                switchFragment(smsFragment, true); // Or new SettingsFragment()
                return true;
            }
            return false;
        });


    }

    private void switchFragment(Fragment fragment, boolean showBottomNav) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentManager.beginTransaction().replace(R.id.fragment_container, fragment).commit();

        // hide navbar if login screen
        if (!(fragment instanceof LoginFragment)) {
            binding.navView.setVisibility(showBottomNav ? View.VISIBLE : View.GONE);
        }

        fragmentTransaction.commit();
    }
}
