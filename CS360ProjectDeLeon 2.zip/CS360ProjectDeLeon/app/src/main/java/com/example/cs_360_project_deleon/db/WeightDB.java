package com.example.cs_360_project_deleon.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeightDB extends SQLiteOpenHelper {
    private static final String DB_STRING = "weight.db";
    private static final int VERSION = 3;

    public WeightDB(Context context) {
        super(context, DB_STRING, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (username TEXT PRIMARY KEY, passwordHash TEXT)");
        db.execSQL("CREATE TABLE weights (username TEXT, weight REAL, date TEXT, FOREIGN KEY(username) REFERENCES users(username))");
        db.execSQL("CREATE TABLE goals (username TEXT, goal REAL, date TEXT,  FOREIGN KEY(username) REFERENCES users(username))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goals");
        onCreate(db);
    }
}
