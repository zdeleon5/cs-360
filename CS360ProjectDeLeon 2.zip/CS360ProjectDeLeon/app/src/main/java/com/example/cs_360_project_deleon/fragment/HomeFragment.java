package com.example.cs_360_project_deleon.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.cs_360_project_deleon.R;
import com.example.cs_360_project_deleon.models.Weight;
import com.example.cs_360_project_deleon.models.dao.WeightDAO;

public class HomeFragment extends Fragment {
    private TextView currentWeightValue;
    private TextView goalWeightValue;
    private TextView weightDifferenceValue;

    @Override
    public void onResume() {
        super.onResume();

        String username = requireContext()
                .getSharedPreferences("user_prefs", 0)
                .getString("username", null);

        if (username != null) {
            WeightDAO weightDAO = new WeightDAO(requireContext());
            double currentWeight = weightDAO.getCurrentWeight(username);
            double goalWeight = weightDAO.getGoalWeight(username);

            Log.d("HomeFragment", "Current weight: " + currentWeight);
            Log.d("HomeFragment", "Goal weight: " + goalWeight);

            currentWeightValue.setText(String.format("%.1f lbs", currentWeight));
            goalWeightValue.setText(String.format("%.1f lbs", goalWeight));
            weightDifferenceValue.setText(String.format("%.1f lbs", goalWeight - currentWeight));
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        return view;


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        currentWeightValue = view.findViewById(R.id.textViewCurrentWeightValue);
        goalWeightValue = view.findViewById(R.id.textViewGoalWeightValue);
        weightDifferenceValue = view.findViewById(R.id.textViewWeightDifferenceValue);

        String username = requireContext()
                .getSharedPreferences("user_prefs", 0)
                .getString("username", null);

        if (username != null) {
            WeightDAO weightDAO = new WeightDAO(requireContext());
            double currentWeight = weightDAO.getCurrentWeight(username);
            double goalWeight = weightDAO.getGoalWeight(username);

            currentWeightValue.setText(String.format("%.1f lbs", currentWeight));
            goalWeightValue.setText(String.format("%.1f lbs", goalWeight));
            weightDifferenceValue.setText(String.format("%.1f lbs", goalWeight - currentWeight));

        }
    }


}
