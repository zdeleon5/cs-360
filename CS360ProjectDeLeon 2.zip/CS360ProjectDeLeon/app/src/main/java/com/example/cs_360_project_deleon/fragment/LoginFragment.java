package com.example.cs_360_project_deleon.fragment;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.cs_360_project_deleon.R;
import com.example.cs_360_project_deleon.models.User;
import com.example.cs_360_project_deleon.models.dao.UserLogInDAO;

public class LoginFragment extends Fragment {

    private EditText editUsername, editPassword;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        editUsername = view.findViewById(R.id.editUsername);
        editPassword = view.findViewById(R.id.editPassword);
        Button buttonLogin = view.findViewById(R.id.buttonLogin);
        Button buttonRegister = view.findViewById(R.id.buttonCreateAccount);

        if (buttonLogin != null) {
            buttonLogin.setOnClickListener(v -> {
                onLoginClick(v);
            });
        }

        if (buttonRegister != null) {
            buttonRegister.setOnClickListener(v -> {
                onRegisterClick(v);
            });
        }
    }

    public void onLoginClick(View view) {
        String user = editUsername.getText().toString();
        String pass = editPassword.getText().toString();

        UserLogInDAO userLogInDAO = new UserLogInDAO(requireContext());
        User user1 = new User(user, pass);

        if(userLogInDAO.validateUser(user1)) {
            Toast.makeText(requireContext(), "Login clicked: " + user, Toast.LENGTH_SHORT).show();
            if (getActivity() != null) {
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, new HomeFragment());
                fragmentTransaction.commit();
            }
        } else {
            Toast.makeText(requireContext(), "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }

        requireContext().getSharedPreferences("user_prefs", 0)
                .edit()
                .putString("username", user)
                .apply();
    }


    public void onRegisterClick(View view) {
        String user = editUsername.getText().toString();
        String pass = editPassword.getText().toString();

        UserLogInDAO userLogInDAO = new UserLogInDAO(requireContext());
        User user1 = new User(user, pass);

        if (userLogInDAO.insertUser(user1)) {
            Toast.makeText(requireContext(), "Registration successful!", Toast.LENGTH_SHORT).show();
            userLogInDAO.logAllUsers();
        } else {
            Toast.makeText(requireContext(), "User already exists.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}