package com.example.cs_360_project_deleon.fragment;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.cs_360_project_deleon.R;
import com.example.cs_360_project_deleon.models.dao.WeightDAO;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SMSFragment extends Fragment {
    SwitchCompat switchSmsNotification;
    private boolean smsPermissionGranted = false;
    private  ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sms_setting, container, false);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        smsPermissionGranted = true;
                        switchSmsNotification.setChecked(true);
                        Toast.makeText(requireContext(), "SMS permission granted", Toast.LENGTH_SHORT).show();

                    } else {
                        smsPermissionGranted = false;
                        switchSmsNotification.setChecked(false);
                        Toast.makeText(requireContext(), "SMS permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView textViewSmsNotificationLabel = view.findViewById(R.id.textViewSmsNotificationLabel);
        switchSmsNotification = view.findViewById(R.id.switchSmsNotification);
        EditText editTextWeightGoal = view.findViewById(R.id.editTextWeightGoal);
        Button buttonAddWeightGoal = view.findViewById(R.id.buttonAddWeightGoal);

        // check permission state
        smsPermissionGranted = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        switchSmsNotification.setChecked(smsPermissionGranted);

        switchSmsNotification.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (!smsPermissionGranted) {
                    requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                }
            } else {
                smsPermissionGranted = false;
            }
        });


        buttonAddWeightGoal.setOnClickListener(v -> {
            String weightGoalStr = editTextWeightGoal.getText().toString();
            String username = requireContext()
                    .getSharedPreferences("user_prefs", 0)
                    .getString("username", null);



            if (username != null && !weightGoalStr.isEmpty()) {
                double weightGoal = Double.parseDouble(weightGoalStr);
                Log.d("SMSFragment", "Weight goal: " + weightGoal);
                WeightDAO weightDAO = new WeightDAO(requireContext());
                String date = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
                boolean success = weightDAO.setGoalWeight(username, weightGoal, date);

                if (success) {
                    Toast.makeText(requireContext(), "Weight goal set successfully", Toast.LENGTH_SHORT).show();
                    editTextWeightGoal.setText("");
                    requireActivity().getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.fragment_container, new HomeFragment())
                            .commit();

                    double currentWeight = weightDAO.getCurrentWeight(username);

                    if (currentWeight == weightGoal && smsPermissionGranted && switchSmsNotification.isChecked()) {
                        sendSmsAlert("Your weight has reached your goal!");
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to set weight goal", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(requireContext(), "Please enter a valid weight goal", Toast.LENGTH_SHORT).show();
            }
        });



        textViewSmsNotificationLabel.setText("SMS Notifications");
    }

    private void sendSmsAlert(String message) {
        String phoneNumber = "9402309564"; // Replace with actual phone number

        try {
            SmsManager smsManager = requireContext().getSystemService(SmsManager.class);
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(requireContext(), "SMS sent successfully", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(requireContext(), "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
