package com.example.cs_360_project_deleon.fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs_360_project_deleon.R;
import com.example.cs_360_project_deleon.models.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }
    private final List<WeightEntry> weightList;
    private OnDeleteClickListener deleteClickListener;

    public WeightAdapter(List<WeightEntry> weightList, OnDeleteClickListener deleteClickListener) {
        this.weightList = weightList;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_item_row, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.textWeight.setText("Weight: " + entry.weight);

        holder.buttonDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView textWeight;
        Button buttonDelete;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textWeight = itemView.findViewById(R.id.textWeight);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
