package com.example.cs_360_project_deleon.fragment;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs_360_project_deleon.R;
import com.example.cs_360_project_deleon.models.Weight;
import com.example.cs_360_project_deleon.models.WeightEntry;
import com.example.cs_360_project_deleon.models.dao.WeightDAO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WeightFragment extends Fragment {
    private TextView textViewGoalWeightDisplay;

    private EditText editTextWeight;
    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private List<WeightEntry> weightList = new ArrayList<>();

    private Button buttonAddWeight;

    @Nullable
    @Override
    public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        assert inflater != null;
        return inflater.inflate(R.layout.fragment_weight, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        textViewGoalWeightDisplay = view.findViewById(R.id.textViewGoalWeightDisplay);
        editTextWeight = view.findViewById(R.id.editTextWeight);
        recyclerView = view.findViewById(R.id.recyclerViewWeights);
        buttonAddWeight = view.findViewById(R.id.buttonAddWeight);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new WeightAdapter(weightList, position -> {
            String username = requireContext()
                    .getSharedPreferences("user_prefs", 0)
                    .getString("username", null);
            String date = weightList.get(position).date;
            WeightDAO weightDAO = new WeightDAO(requireContext());
            boolean success = weightDAO.deleteWeightEntry(username, date);
            if (success) {
                weightList.remove(position);
                adapter.notifyItemRemoved(position);
                Toast.makeText(requireContext(), "Weight entry deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Failed to delete weight entry", Toast.LENGTH_SHORT).show();
            }

        });
        recyclerView.setAdapter(adapter);

        String username = requireContext()
                .getSharedPreferences("user_prefs", 0)
                .getString("username", null);

        loadWeightsFromDatabase(username);

        if (buttonAddWeight != null) {
            buttonAddWeight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onAddWeightClick(v);
                }
            });
        }

        textViewGoalWeightDisplay.setText("Goal Weight: 150 lbs");
    }

    public void onAddWeightClick(View view) {
        String weightStr = editTextWeight.getText().toString();
        if (!weightStr.isEmpty()) {
            double weight = Double.parseDouble(weightStr);
            String username = requireContext()
                    .getSharedPreferences("user_prefs", 0)
                    .getString("username", null);
            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            WeightDAO weightDAO = new WeightDAO(requireContext());
            boolean success = weightDAO.insertWeight(username, weight, date);

            if (success) {
                loadWeightsFromDatabase(username);
                editTextWeight.setText(""); // Clear the input field
                Toast.makeText(requireContext(), "Weight added: ", Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(requireContext(), "Failed to add weight", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(requireContext(), "Please enter a weight", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    private void loadWeightsFromDatabase(String username) {
        WeightDAO weightDAO = new WeightDAO(requireContext());
        List<WeightEntry> weights = weightDAO.getWeightsByUsername(username);

        weightList.clear();
        weightList.addAll(weights);
        adapter.notifyDataSetChanged();
    }


}