package com.example.cs_360_project_deleon.models;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;

@Entity(tableName = "weights")
public class Weight {
    @ColumnInfo(name = "username")
    private String username;
    @ColumnInfo(name = "weight")
    private double weight;
    @ColumnInfo(name = "date")
    private String date;

    public Weight(String username, double weight, String date) {
        this.username = username;
        this.weight = weight;
        this.date = date;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}