package com.example.cs_360_project_deleon.models;

public class WeightEntry {
    public double weight;
    public String date;

    public WeightEntry(double weight, String date) {
        this.weight = weight;
        this.date = date;
    }
}