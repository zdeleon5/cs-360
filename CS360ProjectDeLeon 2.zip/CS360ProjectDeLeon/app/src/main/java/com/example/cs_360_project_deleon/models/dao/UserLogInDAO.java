package com.example.cs_360_project_deleon.models.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;

import com.example.cs_360_project_deleon.db.WeightDB;
import com.example.cs_360_project_deleon.models.User;

@Dao
public class UserLogInDAO {
    private final WeightDB db;
    public UserLogInDAO(Context context) {
        this.db = new WeightDB(context);
    }

    public boolean validateUser(User user) {
        Cursor cursor = db.getReadableDatabase().rawQuery(
            "SELECT * FROM users WHERE username = ? AND passwordHash = ?",
            new String[]{user.getUsername(), user.getPassword()}
        );

        boolean userExists = cursor.moveToFirst();
        cursor.close();
        return userExists;
    }

    @Insert(onConflict = OnConflictStrategy.ABORT)
    public boolean insertUser(User user) {
        Cursor cursor = db.getReadableDatabase().rawQuery(
            "SELECT * FROM users WHERE username = ?",
            new String[]{user.getUsername()}
        );

        boolean userExists = cursor.moveToFirst();
        cursor.close();

        if (userExists) {
            return false; // User already exists
        }

        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        values.put("passwordHash", user.getPassword());
        long result = db.getWritableDatabase().insert("users", null, values);
        return result != -1; // Return true if insert was successful
    }

    public void logAllUsers() {
        Cursor cursor = db.getReadableDatabase().rawQuery("SELECT username FROM users", null);
        while (cursor.moveToNext()) {
            String username = cursor.getString(0);
            Log.d("UserLogInDAO", "User: " + username);
        }
        cursor.close();
    }
}
