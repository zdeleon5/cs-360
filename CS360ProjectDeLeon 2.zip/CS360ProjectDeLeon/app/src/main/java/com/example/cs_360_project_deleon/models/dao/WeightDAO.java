package com.example.cs_360_project_deleon.models.dao;


import android.content.Context;
import android.database.Cursor;

import androidx.room.Dao;
import com.example.cs_360_project_deleon.db.WeightDB;
import com.example.cs_360_project_deleon.fragment.WeightFragment;
import com.example.cs_360_project_deleon.models.Weight;
import com.example.cs_360_project_deleon.models.WeightEntry;

import java.util.ArrayList;
import java.util.List;

@Dao
public class WeightDAO {
    private final WeightDB db;

    public WeightDAO(Context context) {
        this.db = new WeightDB(context);
    }

    public boolean insertWeight(String username, double weight, String date) {
        try {
            db.getWritableDatabase().execSQL(
                "INSERT OR REPLACE INTO weights (username, weight, date) VALUES (?, ?, ?)",
                new Object[]{username, weight, date}
            );
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<WeightEntry> getWeightsByUsername(String username) {
        List<WeightEntry> weights = new ArrayList<>();
        Cursor cursor = db.getReadableDatabase().rawQuery(
            "SELECT weight, date FROM weights WHERE username = ?",
            new String[]{username}
        );

        if (cursor.moveToFirst()) {
            do {
                weights.add(new WeightEntry(cursor.getDouble(0), cursor.getString(1)));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return weights;
    }

    public boolean setGoalWeight(String username, double goalWeight, String date) {
        try {
            db.getWritableDatabase().execSQL(
                "INSERT OR REPLACE INTO goals (username, goal, date) VALUES (?, ?, ?)",
                new Object[]{username, goalWeight, date}
            );
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public double getGoalWeight(String username) {
        double goalWeight = 0.0;
        Cursor cursor = db.getReadableDatabase().rawQuery(
            "SELECT goal FROM goals WHERE username = ? ORDER BY date DESC LIMIT 1",
            new String[]{username}
        );

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
        }
        cursor.close();

        return goalWeight;
    }

    public double getCurrentWeight(String username) {
        double currentWeight = 0.0;
        Cursor cursor = db.getReadableDatabase().rawQuery(
            "SELECT weight FROM weights WHERE username = ? ORDER BY date DESC LIMIT 1",
            new String[]{username}
        );

        if (cursor.moveToFirst()) {
            currentWeight = cursor.getDouble(0);
        }
        cursor.close();

        return currentWeight;
    }

    public boolean deleteWeightEntry(String username, String date) {
        try {
            db.getWritableDatabase().execSQL(
                "DELETE FROM weights WHERE username = ? AND date = ?",
                new Object[]{username, date}
            );
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<WeightEntry> getWeightEntries(String username) {
        List<WeightEntry> entries = new ArrayList<>();
        Cursor cursor = db.getReadableDatabase().rawQuery(
            "SELECT weight, date FROM weights WHERE username = ? ORDER BY date DESC",
            new String[]{username}
        );

        if (cursor.moveToFirst()) {
            do {
                double weight = cursor.getDouble(0);
                String date = cursor.getString(1);
                entries.add(new WeightEntry(weight, date));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return entries;
    }
}
